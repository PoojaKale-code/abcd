package com.cg.training.Exercise1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
//C:\Users\admin\capgemini_nov_2020\SourceFile.txt
public class Exercise1 {

	public static void main(String[] args) throws IOException {
		int j=1;
		char character;
		int i=0;
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter File path: ");
		String string=scanner.next();
		FileInputStream inputFile=new FileInputStream(string);
		int n=inputFile.available();
		System.out.println("Text file lines with numbers");
		System.out.print(j+": ");
		while(i<n)
		{
			character=(char)inputFile.read();
			System.out.print(character);
			if(character=='\n')
			{System.out.print(++j+": ");}
			++i;                 
		}
	}
}
