package com.cg.training.Exercise2;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
//C:\Users\admin\capgemini_nov_2020\SourceFile.txt
public class Exercise2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		BufferedReader buffer=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter file name");
		try {
			String string=buffer.readLine();
			File file=new File(string);
			System.out.println("File name is "+file.getName());
			if(file.canRead())
			{
				System.out.println(file.getName()+" is reable");
			}
			else
			{
				System.out.println(file.getName()+" is not reable");
			}
			if(file.canWrite())
			{
				System.out.println(file.getName()+" is writable");
			}
			else
			{
				System.out.println(file.getName()+" is not writable");
			}
			System.out.println("Filesize:"+file.length()+" bytes");
			String str=file.toString();
			
			    if((str.lastIndexOf('.')) > 0) {
			      String type = str.substring((str.lastIndexOf('.'))+ 1);
			      System.out.println("File extension is " + type);
			    }
			    
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
