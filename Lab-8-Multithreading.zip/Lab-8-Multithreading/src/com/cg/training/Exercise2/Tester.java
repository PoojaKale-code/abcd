package com.cg.training.Exercise2;

public class Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Runnable runnable=new TimerThread();
		Thread t1=new Thread(runnable);
		t1.start();

	}

}
