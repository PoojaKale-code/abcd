package com.cg.training.lab10;
@FunctionalInterface
public interface Interface1 {
	 Double power(Double x,Double y);

}
